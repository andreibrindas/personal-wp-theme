<?php 

add_theme_support( 'title-tag' );
add_theme_support( 'title-tmenusag' );
add_theme_support( 'html5' );
add_theme_support( 'post-thumbnails' );
add_theme_support( 'menus' );
add_theme_support( 'menus' );
